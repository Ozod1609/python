# Uzbekistan Weather Forecast Scraper

This Python script scrapes the 4-day weather forecast for all cities in Uzbekistan from https://hydromet.uz using Selenium and exports the data to an Excel file.

## Features:
- Scrapes city, region, temperature, date, and weekday
- Outputs clean Excel file
- Uses Selenium (headless Chrome) and Pandas

## How to Run:
1. Install dependencies:
   pip install selenium pandas openpyxl
2. Download [ChromeDriver](https://sites.google.com/a/chromium.org/chromedriver/) compatible with your Chrome
3. Run the script:
   python weather_scraper.py

Output will be saved as `weather_forecast.xlsx`.

## Author:
Ozodbek Mukhamadyuldashev
